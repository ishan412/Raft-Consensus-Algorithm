import json
import logging
import uuid

from flask import Blueprint, jsonify, request

from cluster_nodes import get_job_queue, is_current_node_leader, get_raftnode_status, get_connection_pool

bp = Blueprint('tasks', __name__, url_prefix='/tasks')


@bp.route('/', methods=['POST'])
def upload_task():
    if not is_current_node_leader():
        leader_address = get_raftnode_status()['leader']
        return jsonify({
            'status': 'NOT_LEADER',
            'leader': leader_address,
        }), 400

    task = request.json
    logging.debug(f'Received task: {task}')

    task_unique_id = str(uuid.uuid4())

    task['id'] = task_unique_id

    redis_database = get_connection_pool()

    with redis_database.pipeline() as pipes:
        pipes.hset('client_payloads', task_unique_id, json.dumps(task))
        pipes.execute()

    queue = get_job_queue()
    queue.put(task, sync=True)

    return jsonify({
        'status': 'SUBMITTED',
        'id': task_unique_id,
    })
