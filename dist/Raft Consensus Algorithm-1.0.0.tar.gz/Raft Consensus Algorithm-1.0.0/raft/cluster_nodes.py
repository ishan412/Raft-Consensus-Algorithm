import time
from typing import List, Union, Dict
from pysyncobj import SyncObj, SyncObjConf
from pysyncobj.batteries import ReplQueue
import redis
import logging

RAFT_CLUSTER: SyncObj = None

JOB_QUEUE = ReplQueue()
election_process_start_time = 0

db = redis.ConnectionPool(host='localhost', port=6379, db=0)
cache = redis.Redis(connection_pool=db)


def get_connection_pool():
    return redis.Redis(connection_pool=db)


def create_raft_cluster(raft_host: str, partners: List[str]):
    global RAFT_CLUSTER
    if RAFT_CLUSTER:
        return

    logging.info("Creating Raft cluster...")
    conf = SyncObjConf(
        raftMinTimeout=16,
        raftMaxTimeout=20,
        appendEntriesPeriod=3,
        appendEntriesUseBatch=True,
        appendEntriesBatchSizeBytes=300,
        leaderFallbackTimeout=60.0,
        logCompactionMinEntries=10,
        logCompactionMinTime=1,
        connectionTimeout=50,
        commandsWaitLeader=True,
        dynamicMembershipChange=True,
        maxBindRetries=6,
        onStateChanged=state_transition
    )

    partners = [raft_host] + partners

    RAFT_CLUSTER = SyncObj(raft_host, partners, consumers=[get_job_queue()], conf=conf)

    logging.info(RAFT_CLUSTER)
    RAFT_CLUSTER.waitBinded()
    RAFT_CLUSTER.waitReady()
    logging.info("Raft cluster created successfully.")
    logging.info(partners)


def get_raft_cluster() -> Union[SyncObj, None]:
    global RAFT_CLUSTER
    if RAFT_CLUSTER:
        return RAFT_CLUSTER

    raise Exception('No raft cluster found')


def get_job_queue() -> ReplQueue:
    return JOB_QUEUE


def get_raftnode_status() -> Dict:
    status = get_raft_cluster().getStatus()
    status['self'] = status['self'].address

    if status['leader']:
        status['leader'] = status['leader'].address

    serializable_status = {
        **status,
        'is_current_node_leader': status['self'] == status['leader']

    }
    return serializable_status


def get_leader_node() -> str:
    status = get_raft_cluster().getStatus()
    if status['leader']:
        return status['leader'].address

    else:
        return ''


def is_current_node_leader() -> bool:
    return get_raftnode_status().get('is_current_node_leader', False)


def state_transition(oldState, newState):
    global election_process_start_time

    if newState == 2:
        election_process_end_time = time.time()
        if election_process_start_time:
            total_election_time = election_process_end_time - election_process_start_time
            logging.info(f"Leader elected in {total_election_time:.2f} seconds.")
            election_process_start_time = 0
        else:
            logging.info("Current node became leader.")
    elif newState == 0 and oldState != 0:
        election_process_start_time = time.time()
        logging.info("Leader election started.")
