import logging
import random
import threading
import requests
import json

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def send_payloads (current_batch_dict):
    leader_url = "http://localhost:5000/tasks"
    request_headers = {"Content-Type": "application/json"}
    json_data = json.dumps(current_batch_dict)
    logger.debug(f"Sending batch: {json_data}")

    response = requests.post(leader_url, data=json_data, headers=request_headers)
    logger.debug(f"Response status code: {response.status_code}")
    logger.debug(f"Response text: {response.text}")

list_json_payloads = []
avg_size_of_payload = 300
batch_size_requested = 300
number_of_requests = 300
number_of_threads = 10
thread = []
size_of_batch = 0
current_batch_dict = {}

for i in range(1, 300):
    single_payload = {
        "test1": random.randint(1,1000),
        "test2": random.randint(1,1000),
        "test3": random.randint(1,1000),
        "test4": random.randint(1,1000)
    }
    single_payload_size = len(json.dumps(single_payload))

    if size_of_batch + single_payload_size <= batch_size_requested:
            current_batch_dict[f"payload_{i}"] =  single_payload
            size_of_batch += single_payload_size
    else:
        if len(thread) < number_of_threads:
            thrd = threading.Thread(target=send_payloads, args=(current_batch_dict,))
            thread.append(thrd)
            thrd.start()
        current_batch_dict.clear()
        size_of_batch = 0

for thrd in thread:
    thrd.join()
if current_batch_dict:
    send_payloads(current_batch_dict)
