import random
import logging
import time
from typing import Dict

from scheduler_base import Scheduler
from raft_cluster import JOB_QUEUE, is_current_node_leader


class IOHeavyTaskScheduler(Scheduler):
    SLEEP_BETWEEN_TASKS_SECONDS = 0.05

    def startup(self) -> None:
        logging.info('IOHeavyTaskScheduler is started')

    def shutdown(self) -> None:
        logging.info('IOHeavyTaskScheduler is stopped')

    def _simulate_send_task(self, task: Dict) -> None:
        logging.debug(f'IOHeavyTaskScheduler sends the task to the cluster: {task}')
        mean_execution_time = task.get('mean_execution_time', 1.0)
        std_dev = task.get('std_dev', 0.2)
        execution_time = max(0, random.normalvariate(mean_execution_time, std_dev))
        time.sleep(execution_time)

    def handle(self) -> None:
        if JOB_QUEUE.empty() or not is_current_node_leader():
            time.sleep(self.SLEEP_BETWEEN_TASKS_SECONDS)
            return

        task = JOB_QUEUE.get(sync=True)

        self._simulate_send_task(task)


class SchedulerFactory:
    @staticmethod
    def create_scheduler(scheduler_type: str = 'io') -> Scheduler:
        if scheduler_type == 'io':
            return IOHeavyTaskScheduler()
