import logging
import signal
from typing import List
from flask import Flask

import raft_cluster_status
import client_tasks
from cluster_nodes import create_raft_nodes, get_raft_cluster
from process_task import PayloadManager


def create_app(raft_host: str, partners: List[str]):
    logging.basicConfig(level=logging.DEBUG, force=True)

    app = Flask(__name__)

    create_raft_nodes(raft_host, partners)
    sync_obj = get_raft_cluster()

    app.register_blueprint(client_tasks.bp)
    app.register_blueprint(raft_cluster_status.bp)

    scheduler = PayloadManager.create_scheduler()
    scheduler.start()

    def sigint_handler(signum, frame):
        scheduler.stop()
        sync_obj.destroy()
        exit(0)

    signal.signal(signal.SIGINT, sigint_handler)

    return app
