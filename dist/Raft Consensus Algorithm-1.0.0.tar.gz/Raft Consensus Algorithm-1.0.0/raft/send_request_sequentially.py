import time
import requests
import logging

get_leader_url = "http://localhost:5002/status/leader"
sending_payload_url = "http://localhost:5000/tasks"

client_payload = {
    "test1":1,
    "test2":2,
    "test3":3,
    "test4":4
}

def fetch_raft_leader():
    try:
        httpresponse=requests.get(get_leader_url)
        if httpresponse.status_code == 200:
            leadernode = httpresponse.json()
            return leadernode.get("leader")
        else:
            logging.info("Error in fetching leader node url")
            return None
    except requests.exceptions.RequestException as e:
        logging.error("Error", e)
        return None

def sending_json_payload(leader_node_url):
    try:
        httpresponse = requests.post(leader_node_url, json=client_payload)
        if httpresponse.status_code == 200:
            logging.info("Client payload sent to the leader successfully")
        else:
            logging.info("There is a problem in sending payload")
    except requests.exceptions.RequestException as e:
        logging.error("Error", e)

while True:
    leader = fetch_raft_leader()
    if leader:
        sending_payload_url = sending_payload_url.replace("localhost:5000",leader)
        sending_json_payload(sending_payload_url)

    time.sleep(2)


