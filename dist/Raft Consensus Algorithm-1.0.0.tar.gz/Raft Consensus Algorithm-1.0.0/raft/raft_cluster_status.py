import json

from flask import Blueprint, current_app, jsonify

from cluster_nodes import get_raftnode_status, get_leader_node

bp = Blueprint('status', __name__, url_prefix='/status')


@bp.route('/raft', methods=['GET'])
def raft_node_status():
    return current_app.response_class(
        json.dumps(get_raftnode_status(), indent=4, sort_keys=True),
        mimetype='application/json')


@bp.route('/leader', methods=['GET'])
def leader_node_url():
    leader = get_leader_node()
    if leader:
        return jsonify({
            'status': 'SUCCESS',
            'leader': leader,
        }), 200

    else:
        return jsonify({
            'status': 'Leader not found',
            'message': 'NO leader is elected yet in the cluster'
        }), 404
