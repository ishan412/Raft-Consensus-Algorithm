import json
import random
import logging
import time
from typing import Dict

from client_task_scheduler import cluster_Scheduler
from cluster_nodes import JOB_QUEUE, is_current_node_leader, get_connection_pool


class IOHeavyTaskClusterScheduler(cluster_Scheduler):
    SLEEP_TIME = 0.05

    def startup(self) -> None:
        logging.info('IOHeavyTaskScheduler is started')
        self.db_connection = get_connection_pool()
        self.batch_queue = []

    def shutdown(self) -> None:
        logging.info('IOHeavyTaskScheduler is stopped')

    def _simulate_send_task_to_leader(self, task: Dict) -> None:
        logging.debug(f'IOHeavyTaskScheduler sends the task to the cluster from redis db: {task}')
        with self.db_connection.pipeline() as pipes:
            task_id = task['id']
            pipes.hget('client_payloads', task_id)
            pipes.hdel('client_payloads', task_id)
            value = pipes.execute()

        payload = json.loads(value[0])
        self.payload_processing(payload)

    def payload_processing(self, client_payload: Dict) -> None:
        task_id = client_payload.get('id')
        if not task_id:
            logging.warning(f"Invalid payload with ID: {task_id}")
            return
        logging.debug(f"Processing payload with id: {task_id}")
        mean_processing_time = client_payload.get('mean_processing_time', 1.0)
        standard_deviation_from_mean = client_payload.get('standard_deviation', 0.2)
        processing_time = max(0, random.normalvariate(mean_processing_time, standard_deviation_from_mean))

        logging.debug(f"Processing time for task with {task_id}: {processing_time}")

    def get_payload_from_db(self, task_id: str) -> Dict:
        redis_database = get_connection_pool()
        payload = redis_database.hget('client_payloads', task_id)
        return json.loads(payload)

    def handle(self) -> None:
        if JOB_QUEUE.empty() or not is_current_node_leader():
            time.sleep(self.SLEEP_TIME)
            return

        task = JOB_QUEUE.get(sync=True)
        payload = self.get_payload_from_db(task['id'])

        self._simulate_send_task_to_leader(payload)


class PayloadManager:
    @staticmethod
    def create_scheduler(scheduler_type: str = 'io') -> cluster_Scheduler:
        if scheduler_type == 'io':
            return IOHeavyTaskClusterScheduler()
