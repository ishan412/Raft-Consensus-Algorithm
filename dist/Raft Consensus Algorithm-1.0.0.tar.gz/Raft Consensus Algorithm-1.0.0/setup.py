from setuptools import setup

setup(
    name="Raft Consensus Algorithm",
    version="1.0.0",
    packages=['raft'],
    description="Testing functionalities of Raft consensus protocol using pySyncObj python package"
)
