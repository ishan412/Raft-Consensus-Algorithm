from setuptools import setup

setup(
    name = "Raft Consensus Algorithm",
    version = "1.0.0",
    packages = ['raft'],
    author = "Ishan Upadhyay",
    description = "Testing functionalities of Raft consensus protocol using pySyncObj python package"
)