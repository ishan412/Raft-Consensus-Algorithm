from typing import List, Union, Dict

from pysyncobj import SyncObj
from pysyncobj.batteries import ReplQueue

RAFT_CLUSTER: SyncObj = None
JOB_QUEUE = ReplQueue()


def create_raft_cluster(raft_host: str, partners: List[str]):
    global RAFT_CLUSTER
    if RAFT_CLUSTER:
        return

    print("Creating Raft cluster...")
    print(partners)
    #partner_addresses = [p.split(':') for p in partners]  # Split each partner string into host and port
    #RAFT_CLUSTER = SyncObj(raft_host.split(':'), partner_addresses, consumers=[get_job_queue()])
    print(partners)
    RAFT_CLUSTER = SyncObj(raft_host, partners, consumers=[get_job_queue()])
    print(RAFT_CLUSTER)
    RAFT_CLUSTER.waitBinded()
    RAFT_CLUSTER.waitReady()
    print("Raft cluster created successfully.")
    print(partners)


def get_raft_cluster() -> Union[SyncObj, None]:
    global RAFT_CLUSTER
    if RAFT_CLUSTER:
        return RAFT_CLUSTER

    raise Exception('Raft cluster is not created')


def get_job_queue() -> ReplQueue:
    return JOB_QUEUE


def get_status() -> Dict:
    status = get_raft_cluster().getStatus()
    status['self'] = status['self'].address

    if status['leader']:
        status['leader'] = status['leader'].address

    serializable_status = {
        **status,
        'is_current_node_leader': status['self'] == status['leader']
    }
    return serializable_status


def is_current_node_leader() -> bool:
    return get_status().get('is_current_node_leader', False)
